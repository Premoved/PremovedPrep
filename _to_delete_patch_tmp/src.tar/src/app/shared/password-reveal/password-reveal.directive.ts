import { Directive, ElementRef, OnDestroy, OnInit, Renderer2, inject } from '@angular/core';

@Directive({
	selector: 'input[appPasswordReveal]',
})
export class PasswordRevealDirective implements OnInit, OnDestroy {
	private readonly input = inject<ElementRef<HTMLInputElement>>(ElementRef).nativeElement;
	private readonly renderer = inject(Renderer2);

	private button: HTMLButtonElement | null = null;
	private shown = false;
	private detach: (() => void) | null = null;

	ngOnInit(): void {
		const parent = this.renderer.parentNode(this.input) as HTMLElement | null;
		if (!parent) {
			return;
		}

		const wrapper = this.renderer.createElement('span') as HTMLElement;
		this.renderer.addClass(wrapper, 'password-field');
		this.renderer.insertBefore(parent, wrapper, this.input);
		this.renderer.appendChild(wrapper, this.input);

		const button = this.renderer.createElement('button') as HTMLButtonElement;
		// Not 'submit': this button lives inside forms and must not trigger their default submit.
		this.renderer.setAttribute(button, 'type', 'button');
		// Off the tab order: a keyboard user tabbing from the field expects the submit button next.
		this.renderer.setAttribute(button, 'tabindex', '-1');
		this.renderer.addClass(button, 'password-reveal');
		button.innerHTML = ICON;
		this.renderer.appendChild(wrapper, button);

		this.button = button;
		this.detach = this.renderer.listen(button, 'click', () => this.toggle());
		this.describe();
	}

	ngOnDestroy(): void {
		this.detach?.();
	}

	private toggle(): void {
		this.shown = !this.shown;
		this.renderer.setAttribute(this.input, 'type', this.shown ? 'text' : 'password');
		this.describe();
		// Changing the input's type moves focus off it in some browsers; put the caret back.
		this.input.focus();
	}

	private describe(): void {
		if (!this.button) {
			return;
		}
		const label = this.shown ? 'Hide password' : 'Show password';
		this.renderer.setAttribute(this.button, 'aria-label', label);
		this.renderer.setAttribute(this.button, 'title', label);
		this.renderer.setAttribute(this.button, 'aria-pressed', String(this.shown));
	}
}

// Boxicons v3.0.8 - https://boxicons.com | License https://docs.boxicons.com/free
const ICON = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5c-1.84 0-3.35.39-4.62.97L3.7 2.29 2.29 3.7l3.32 3.32C3 8.97 2.07 11.64 2.05 11.68c-.07.21-.07.43 0 .63.02.07 2.32 6.68 9.95 6.68 1.84 0 3.35-.39 4.62-.97l3.68 3.68 1.41-1.41-3.32-3.32c2.61-1.95 3.54-4.62 3.56-4.66.07-.21.07-.43 0-.63C21.93 11.61 19.63 5 12 5m-7.93 7c.1-.24.27-.59.52-.99l5.87 5.87c-4.21-.65-5.94-3.84-6.39-4.88m9.25 4.91L5.84 9.43c.34-.34.74-.67 1.19-.98l8.05 8.05c-.53.19-1.12.33-1.76.41m3.65-1.35-1.53-1.53c.61-1.03.71-2.28.31-3.38-.18.21-.45.36-.75.36-.55 0-1-.45-1-1 0-.44.29-.81.69-.94a3.98 3.98 0 0 0-4.71-.5L8.92 7.51c.88-.31 1.9-.5 3.08-.5 5.35 0 7.42 3.85 7.93 5-.3.69-1.17 2.34-2.96 3.56Z"/></svg>`;
